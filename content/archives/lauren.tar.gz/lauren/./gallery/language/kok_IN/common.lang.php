<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
/*
Language Name: कोंकणी [IN]
Version: 2.10.2
Language URI: http://piwigo.org/ext/extension_view.php?eid=660
Author: Piwigo team
Author URI: http://piwigo.org
*/

$lang_info['language_name'] = 'कोंकणी';
$lang_info['country'] = 'भारत';
$lang_info['direction'] = 'ltr';
$lang_info['code'] = 'kok';
$lang_info['zero_plural'] = true;

$lang['%d album updated'] = '%d आल्बम अद्यावत केला';
$lang['%d albums updated'] = '%d आल्बम अद्यावत केल्यात';
$lang['%d comment to validate'] = '%d वैध थारावूंक टिप्पणी दिवची';
$lang['%d comment'] = '%d टिप्पणी';
$lang['%d comments to validate'] = '%d वैध थारावूंक टिप्पण्यो दिवच्यो';
$lang['%d comments'] = '%d टिप्पण्यो';
$lang['%d hit'] = '%d हिट';
$lang['%d hits'] = '%d हिट्स';
$lang['%d Kb'] = '%d केबी';
$lang['%d new comment'] = '%d नवी टिप्पणी';
$lang['%d new comments'] = '%d नव्यो टिप्पण्यो';
$lang['%d new photo'] = '%d नवो फोटो';
$lang['%d new photos'] = '%d नवे फोटे';
$lang['%d new user'] = '%d नवो वापरपी';
$lang['%d new users'] = '%d नवे वापरपी';
$lang['%d photo is also linked to current tags'] = '%d फोटो सध्याच्या टॅग्सांक लिंक्ड केल्ले आसात';
$lang['%d photo'] = '%d फोटो';
$lang['%d photos are also linked to current tags'] = '%d फोटे सध्याच्या टॅग्सांक लिंक्ड केल्ले आसात';
$lang['%d photos'] = '%d फोटे';
$lang['%d rates'] = '%d दर';
$lang['(!) This comment requires validation'] = '(!) हे टिप्पणीक सत्यत्वस्थापनाची आवश्यकता आसा';
$lang['... or browse your empty gallery'] = '... वा तुमची रिकामी गॅलरी ब्रावज करची';
$lang['... or please deactivate this message, I will find my way by myself'] = '... वा उपकार करून हो संदेश असक्रीय करचो, म्हजी वाट हांव स्वता सोदून काडटलों';
$lang['A comment on your site'] = 'तुमचे सायटीटचेर टिप्पणी';
$lang['About Piwigo'] = 'Piwigo विशीं';
$lang['About'] = 'विशीं';
$lang['Date'] = "तारीख";
$lang['day'][0] = "आयतार";
$lang['day'][1] = "सोमार";
$lang['day'][2] = "मंगळार";
$lang['day'][3] = "बुधवार";
$lang['day'][4] = "बिरेस्तार";
$lang['day'][5] = "शुक्रार";
$lang['day'][6] = "शेनवार";
$lang['month'][10] = "ऑक्टोबर";
$lang['month'][11] = "नोव्हेंबर";
$lang['month'][12] = "डिसेंबर";
$lang['month'][1] = "जानेवारी";
$lang['month'][2] = "फेब्रुवारी";
$lang['month'][3] = "मार्च";
$lang['month'][4] = "एप्रिल";
$lang['month'][5] = "मे";
$lang['month'][6] = "जून";
$lang['month'][7] = "जुलाय";
$lang['month'][8] = "ऑगस्ट";
$lang['month'][9] = "सप्टेंबर";
$lang['Username is mandatory'] = 'वापरप्याचें नांव सक्तीचें आसा';
$lang['Username: %s'] = 'वापरप्याचें नांव: %s';
$lang['View in'] = 'दृश्य करचें';
$lang['View'] = 'दृश्य';
$lang['Visits'] = 'भेटी';
$lang['Visits, high &rarr; low'] = 'भेटी, चड &rarr; निम्न';
$lang['Visits, low &rarr; high'] = 'भेटी, निम्न &rarr; चड';
$lang['Website'] = 'वॅबसायट';
$lang['Webmaster'] = 'वॅबमास्टर';
$lang['Week %d'] = 'सप्तक %d';
$lang['Welcome to your Piwigo photo gallery!'] = 'तुमचे Piwigo फोटो गॅलरीक येवकार!';
$lang['Welcome'] = 'येवकार';
$lang['wrong date'] = 'चुकीची तारीख';
$lang['xlarge'] = 'XL – मायझ व्हड';
$lang['xsmall'] = 'XS – मायझ ल्हान';
$lang['xxlarge'] = 'XXL - व्हडलें';
$lang['Yes'] = 'हय';
$lang['You are not authorized to access the requested page'] = 'मागणी केल्ल्या पानांक ऍक्सॅस करूंक तुमकां अधिकार ना';
$lang['You will receive a link to create a new password via email.'] = 'तुमकां ई-मेली वरवीं नवो पासवर्ड निर्माण करूंक एक लिंक मेळटलें.';
$lang['Your comment has been registered'] = 'तुमची टिप्पणीची नोंदणी केल्या';
$lang['Your comment has NOT been registered because it did not pass the validation rules'] = 'तुमची टिप्पणी नोंदणी केल्ली ना कारण ती वैधताय नियमाचो पाळो करिना';
$lang['Your favorites'] = 'तुमचे आवडीचे';
$lang['Repeat the slideshow'] = 'स्लायडशो परत दाखोवचो';
$lang['representative'] = 'आल्बम थंबनेल';
$lang['Requested album does not exist'] = 'मागणी केल्लो आल्बम अस्तित्वांत ना';
$lang['Requested tag does not exist'] = 'मागणी केल्लो टॅग अस्तित्वांत ना';
$lang['Reset to default values'] = 'डिफॉल्ट मोलाचेर परत सॅट करचें';
$lang['Reset'] = 'परत सॅट करचें';
$lang['Retrieve password'] = 'पासवर्ड परत मेळोवचो';
$lang['Return to home page'] = 'मुखेल पानाचेर परतुचें';
$lang['return to normal view mode'] = 'सामान्य दृश्य मोडाचेर परतुचें';
$lang['return to the display of all photos'] = 'सगळ्या फोट्याच्या प्रदर्शनाचेर परतुचें';
$lang['Search by date'] = 'तारखे प्रमाणें सोदचें';
$lang['Search for all terms'] = 'सगळ्या शब्दांक सोदचे';
$lang['Search for any term'] = 'खंयच्याय शब्दाक सोदचो';
$lang['Search for Author'] = 'लेखकाक सोदचो';
$lang['Search for words'] = 'उतरां सोदचीं';
$lang['Search in albums'] = 'आल्बमांनी सोदचें';
$lang['Search in sub-albums'] = 'उप-आल्बमांनी सोदचें';
$lang['Search results'] = 'सोद निकाल';
$lang['Search rules'] = 'सोद निकश';
$lang['Search tags'] = 'सोदपाचे टॅग्स';
$lang['Search'] = 'सोद';
$lang['search'] = 'सोद';

?>