<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
/*
Language Name: বাংলা[IN]
Version: 2.10.2
Language URI: http://piwigo.org/ext/extension_view.php?eid=657
Author: Piwigo team
Author URI: http://piwigo.org
*/

$lang_info['language_name'] = 'বাংলা';
$lang_info['country'] = 'ভারত';
$lang_info['direction'] = 'ltr';
$lang_info['code'] = 'bn';
$lang_info['zero_plural'] = true;


$lang['%d album updated'] = '%d অ্যালবাম আপডেট হয়েছে';
$lang['%d albums updated'] = '%d অ্যালবামগুলি আপডেট হয়েছে';
$lang['%d comment to validate'] = '%d সক্রিয় করতে মন্তব্য';
$lang['%d comment'] = '%d মন্তব্য';
$lang['%d comments to validate'] = '%d সক্রিয় করতে মন্তব্যগুলি';
$lang['%d comments'] = '%d মন্তব্যগুলি';
$lang['%d hit'] = '%d hit';
$lang['%d hits'] = '%d hits';
$lang['%d Kb'] = '%d Kb';
$lang['%d new comment'] = '%d নূতন মন্তব্য';
$lang['%d new comments'] = '%d নূতন মন্তব্যসমূহ';
$lang['%d new photo'] = '%d নূতন ছবি';
$lang['%d new photos'] = '%d নূতন ছবিসমূহ';
$lang['%d new user'] = '%d নূতন গ্রাহক';
$lang['%d new users'] = '%d নূতন গ্রাহকগণ';
$lang['%d photo is also linked to current tags'] = '%d বর্তমান ট্যাগের সাথে ছবি সংযোজিত আছে';
$lang['%d photo'] = '%d ছবি';
$lang['%d photos are also linked to current tags'] = '%d বর্তমান ট্যাগের সাথে ছবি সংযোজিত আছে';
$lang['%d photos'] = '%d ছবিসমূহ';
$lang['%d rates'] = '%d rates';
$lang['(!) This comment requires validation'] = '(!) মন্তব্য বৈধ করতে হবে';
$lang['... or browse your empty gallery'] = '... অথবা আপনার খালি গ্যালারী দেখুন';
$lang['... or please deactivate this message, I will find my way by myself'] = '... অথবা মন্তব্যটি নিষ্ক্রিয় করুন, আমি আমার করণীয় নিজেই করতে পারব';
$lang['A comment on your site'] = 'আপনার সাইটে একটি মন্তব্য';
$lang['About Piwigo'] = 'পিউইগো বিষয়ক';
$lang['About'] = 'বিষয়ক';
$lang['Date']      = 'তারিখ';
$lang['day'][0]    = 'রবিবার';
$lang['day'][1]    = 'সোমবার';
$lang['day'][2]    = 'মঙ্গলবার';
$lang['day'][3]    = 'বুধবার';
$lang['day'][4]    = 'বৃহস্পতিবার';
$lang['day'][5]    = 'শুক্রবার';
$lang['day'][6]    = 'শনিবার';
$lang['month'][10] = 'অক্টোবর';
$lang['month'][11] = 'নভেম্বর';
$lang['month'][12] = 'ডিসেম্বর';
$lang['month'][1]  = 'জানুয়ারী';
$lang['month'][2]  = 'ফেব্রুয়ারি';
$lang['month'][3]  = 'মার্চ';
$lang['month'][4]  = 'এপ্রিল';
$lang['month'][5]  = 'মে';
$lang['month'][6]  = 'জুন';
$lang['month'][7]  = 'জুলাই';
$lang['month'][8]  = 'অগাস্ট';
$lang['month'][9]  = 'সেপ্টেম্বর';
?>